# 🕯️ NecroGit Web Documentation Workbench

This directory contains the self-contained static web interface for NecroGit.

### How to Preview Locally:
```bash
python -m http.server 8080
```
Then open `http://localhost:8080` in your browser.
